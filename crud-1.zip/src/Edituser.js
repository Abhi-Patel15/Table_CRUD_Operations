import React, { useEffect, useState } from "react";
import "./App.css";
import { useParams } from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  Container,
  Typography,
  InputLabel,
  Input,
  Box,
  Button,
} from "@material-ui/core";

const EditUser = () => {
  const [users, setUsers] = useState({
    name: "",
    username: "",
    email: "",
    phone: "",
  });
  const [validation, setValidation] = useState({
    name: "",
    username: "",
    email: "",
    phone: "",
  });
  const { id } = useParams();
  const isAddMode = !id;
  const number = new RegExp("[0-9]{10}");
  const { name, username, email, phone } = users;
  const navigate = useNavigate();
  var pattern = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );

  useEffect(() => {
    if(!isAddMode){
    dataFile();
    }
  }, []);

  /******************** HANDLECHANGE FUNCTION ***********************/
  const handleChange = (e) => {
    setUsers({ ...users, [e.target.name]: e.target.value });
  };

  /******************** ONSUBMIT FUNCTION **************************/
  const handleSubmit = (e) => {
    e.preventDefault();
    ValidationForms();
    if (isAddMode) {
      addSubmitData();
    } else {
      editSubmitData();
    }
  };

  /******************** API CALL START HERE **************************/
  const dataFile = async () => {
    const result = await axios.get(`http://localhost:3500/users/${id}`);
    setUsers(result.data, "res");
  };

  const addSubmitData = async (e) => {
    await axios.post(`http://localhost:3500/users`, users);
    if (
      !users.username == "" &&
      !users.phone == "" &&
      !users.phone.match(number) == "" &&
      !users.name == "" &&
      !users.email == "" &&
      !users.email.match(pattern) == ""
    ) {
      navigate("/");
    }
  };

  const editSubmitData = async (e) => {
    await axios.put(`http://localhost:3500/users/${id}`, users);
    if (
      !users.username == "" &&
      !users.phone == "" &&
      !users.name == "" &&
      !users.phone.match(number) == "" &&
      !users.email == "" &&
      !users.email.match(pattern) == ""
    ) {
      navigate("/");
    }
  };
  /******************** API CALL END HERE **************************/

  /******************** VALIDATION START HERE **********************/
  const ValidationForms = () => {
    let errors = { ...validation };
    if (!users?.name.trim()) {
      errors.name = " name is required";
    } else {
      errors.name = "";
    }
    if (!users.username.trim()) {
      errors.username = "username is required";
    } else {
      errors.username = "";
    }
    if (!users.email.trim()) {
      errors.email = "Email is required";
    } else if (!users.email.match(pattern)) {
      errors.email = "Please ingress a valid email address";
    } else {
      errors.email = "";
    }
    if (!users.phone.trim()) {
      errors.phone = "phone is required";
    } else if (!users.phone.match(number)) {
      errors.phone = "Please provide valid phone number";
    } else {
      errors.phone = "";
    }
    return setValidation(errors);
  };
  /******************** VALIDATION END HERE ***********************/
  return (
    <Container maxWidth="sm">
      <Box my={5}>
        <Typography variant="h5" align="center">
          {!id ? "add user detaile" : "Edit User Details"}
        </Typography>
        <form>
          <InputLabel>Name</InputLabel>
          <Input 
          type="name"
          name="name" 
          onChange={handleChange}
          value={name} />
          {validation?.name && !users.name? 
            <p style={{ color: "red" }}>{validation?.name}</p>
          : null }
       
          <InputLabel>User Name</InputLabel>
          <Input
            type="text"
            name="username"
            onChange={handleChange}
            value={username}
          />
          {validation?.username && !users.username?
            <p style={{ color: "red" }}> {validation?.username}</p>
          : null}
          <InputLabel>Email address</InputLabel>
          <Input
            type="email"
            name="email"
            onChange={handleChange}
            value={email}
          />
          {validation?.email &&!users.email.match(pattern)?
            <p style={{ color: "red" }}>{validation?.email}</p>:
            null
          }
          <InputLabel>Phone Number</InputLabel>
          <Input
            type="text"
            name="phone"
            onChange={handleChange}
            value={phone}
            required
          />
          {validation?.phone && !users.phone.match(number) ?
            <p style={{ color: "red" }}>{validation?.phone}</p>
          : null }
          <Box my={3} className="mt-4">
            <Button
              variant="contained"
              type="submit"
              color="primary"
              align="center"
              onClick={handleSubmit}
            >
              {!id ? "add user" : "Update User"}
            </Button>
          </Box>
        </form>
      </Box>
    </Container>
  );
};

export default EditUser;
