
import './App.css';
import {  BrowserRouter as Router, Routes, Route, } from 'react-router-dom';
import  Edituser  from './Edituser';
import Home from './Home';

function App() {
  return (
    <div>
      <Router>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path= 'user/edit/:id' element={<Edituser />} />
          <Route path= 'user/adduser' element={<Edituser />} />
         </Routes>
      </Router>

    </div>
  );
}

export default App;
