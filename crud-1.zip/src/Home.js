import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import axios from "axios";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import ModeEditOutlineRoundedIcon from "@mui/icons-material/ModeEditOutlineRounded";
import { Link } from "react-router-dom";


 /******************** TABLE STYLE START HEAR ************************/
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

 /******************** TABLE STYLE END HEAR ************************/

export default function Home() {

  const [users, setUsers] = React.useState([]);
  React.useEffect(() => {
    dataFile();
  }, []);

  /******************** API CALL START HERE ************************/
  const dataFile = async () => {
    const result = await axios.get(`http://localhost:3500/users`);
    setUsers(result.data);
  };
  
const dataDelete = async (id) => {
  await axios.delete(`http://localhost:3500/users/${id}`);
  dataFile();
};
  /******************** API CALL END HERE **************************/
  return (
    <div className="mt-5">
      <div className="d-flex justify-content-center">
        <Link to="user/adduser" type="button" className="btn btn-primary mt-3">
          addUser
        </Link>
      </div>
      <TableContainer component={Paper} className="marrgin_1">
        <h1>Users Data</h1>
        <Table sx={{ minWidth: 700 }} aria-label="customized table">
          <TableHead>
            <TableRow>
              <StyledTableCell>Id</StyledTableCell>
              <StyledTableCell align="center">Name</StyledTableCell>
              <StyledTableCell align="center">UserName</StyledTableCell>
              <StyledTableCell align="center">email</StyledTableCell>
              <StyledTableCell align="center">Phone</StyledTableCell>
              <StyledTableCell align="center">action</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((row, index) => (
              <StyledTableRow key={index + 1}>
                <StyledTableCell component="th" scope="row">
                  {index + 1}
                </StyledTableCell>
                <StyledTableCell align="center">{row.name}</StyledTableCell>
                <StyledTableCell align="center">{row.username}</StyledTableCell>
                <StyledTableCell align="center">{row.email}</StyledTableCell>
                <StyledTableCell align="center">{row.phone}</StyledTableCell>
                <StyledTableCell align="center">
                  <IconButton
                    variant="outlined"
                    color="error"
                    aria-label="delete"
                    onClick={() => dataDelete(row.id)}
                  >
                    <DeleteIcon />
                  </IconButton>
                  <Link to={`user/edit/${row.id}`}>
                    {" "}
                    <IconButton
                      aria-label="edit"
                      variant="outlined"
                      color="info"
                    >
                      <ModeEditOutlineRoundedIcon />
                    </IconButton>
                  </Link>
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}
